{{/*
Expand the name of the chart.
*/}}
{{- define "k8squad.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name (63 char limit, per DNS label rules).
*/}}
{{- define "k8squad.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s" (include "k8squad.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Common labels applied to chart-owned resources.
*/}}
{{- define "k8squad.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{ include "k8squad.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: k8squad
{{- end -}}

{{/*
Selector labels. The control-plane namespace carries only stable selectors so
that later epics can match resources without binding to chart version.
*/}}
{{- define "k8squad.selectorLabels" -}}
app.kubernetes.io/name: {{ include "k8squad.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Control-plane namespace resolver — every workload lands in the chart namespace.
*/}}
{{- define "k8squad.namespace" -}}
{{- .Values.namespace.name | default "k8squad-system" -}}
{{- end -}}

{{/*
Per-component selector labels. `ctx` is a dict {root, component}. The
`ksquad.io/component` selector is stable across chart versions so Services and
later epics can bind to a workload without pinning app version.
*/}}
{{- define "k8squad.componentSelectorLabels" -}}
app.kubernetes.io/name: {{ include "k8squad.name" .root }}
app.kubernetes.io/instance: {{ .root.Release.Name }}
ksquad.io/component: {{ .component }}
{{- end -}}

{{/*
Per-component full labels (common labels + component selector).
*/}}
{{- define "k8squad.componentLabels" -}}
{{ include "k8squad.labels" .root }}
ksquad.io/component: {{ .component }}
{{- end -}}

{{/*
Container image ref for a component. `ctx` is a dict {root, component}.
Registry+repo default to ghcr.io/k8squad/ksquad-<component>; tag falls back to
the chart appVersion so a bare `controlPlane.enabled=true` pins a real image.
*/}}
{{- define "k8squad.image" -}}
{{- $img := .root.Values.controlPlane.image -}}
{{- $registry := $img.registry | default "ghcr.io/k8squad" -}}
{{- $tag := $img.tag | default .root.Chart.AppVersion -}}
{{- printf "%s/ksquad-%s:%s" $registry .component $tag -}}
{{- end -}}

{{/*
NATS JetStream replicas — single-replica default; nats.ha.enabled flips to a
clustered RAFT quorum.
*/}}
{{- define "k8squad.nats.replicas" -}}
{{- if .Values.controlPlane.nats.ha.enabled -}}{{ .Values.controlPlane.nats.ha.replicas }}{{- else -}}1{{- end -}}
{{- end -}}

{{/*
StorageClass for the JetStream file-store PVC. Its own knob (§16.2) — no silent
cluster-default fallback; nats.yaml fails fast when this is empty.
*/}}
{{- define "k8squad.storageClass.nats" -}}
{{- .Values.controlPlane.nats.persistence.storageClassName -}}
{{- end -}}

{{/*
NATS client URL for the relay. Precedence: an explicit eventRelay.natsUrl
(external bus) wins; else, when the bundled bus is on, derive it from the
chart-owned Service; else empty (event-relay fails closed on empty).
*/}}
{{- define "k8squad.nats.url" -}}
{{- if .Values.controlPlane.eventRelay.natsUrl -}}
{{- .Values.controlPlane.eventRelay.natsUrl -}}
{{- else if .Values.controlPlane.nats.enabled -}}
{{- printf "nats://ksquad-nats.%s.svc:%v" (include "k8squad.namespace" .) (.Values.controlPlane.nats.port | default 4222) -}}
{{- end -}}
{{- end -}}

{{/*
Effective event-relay enablement — explicitly on, OR implied by the bundled bus
(controlPlane.nats.enabled auto-wires the relay so `controlPlane.enabled` alone
yields a complete event plane).
*/}}
{{- define "k8squad.eventRelay.enabled" -}}
{{- if or .Values.controlPlane.eventRelay.enabled .Values.controlPlane.nats.enabled -}}true{{- end -}}
{{- end -}}

{{/*
OTLP exporter env block, shared by every control-plane workload. Emits the
standard OTEL_EXPORTER_OTLP_* vars pointing at the observability gateway
collector (live since ISI-3484). The operator honors these as a per-signal
stdout fallback (ISI-4102): any signal the OTelConfig CR does not route exports
to this endpoint instead of stdout, so operator telemetry reaches the gateway
even without a CR. The other control-plane binaries still log via pkg/telemetry
(stdout) and treat this env as inert forward-wiring for the ISI-3103 OTLP spine.
*/}}
{{- define "k8squad.otelEnv" -}}
{{- if .Values.controlPlane.otel.enabled }}
- name: OTEL_EXPORTER_OTLP_ENDPOINT
  value: {{ .Values.controlPlane.otel.endpoint | quote }}
- name: OTEL_EXPORTER_OTLP_PROTOCOL
  value: {{ .Values.controlPlane.otel.protocol | quote }}
{{- end }}
{{- end -}}

{{/*
DATABASE_URL env sourced from the configured secret (or the chart-rendered
dev secret). Callers that need Postgres include this block.
*/}}
{{- define "k8squad.databaseEnv" -}}
- name: DATABASE_URL
  valueFrom:
    secretKeyRef:
      {{- if .Values.controlPlane.database.existingSecret }}
      name: {{ .Values.controlPlane.database.existingSecret }}
      key: {{ .Values.controlPlane.database.key | default "dsn" }}
      {{- else }}
      name: {{ include "k8squad.fullname" . }}-database
      key: dsn
      {{- end }}
{{- end -}}

{{/*
Bootstrap-admin env (feature 15.2, ISI-3530). Emitted only when
controlPlane.apiserver.bootstrapAdmin.enabled=true. The password ALWAYS comes
from a Secret — never plaintext values — so we fail-fast if the operator turned
the seed on without supplying a username and existingSecret.
*/}}
{{- define "k8squad.bootstrapAdminEnv" -}}
{{- $ba := .Values.controlPlane.apiserver.bootstrapAdmin | default dict -}}
{{- if $ba.enabled -}}
{{- if not $ba.username }}{{ fail "controlPlane.apiserver.bootstrapAdmin.enabled=true requires controlPlane.apiserver.bootstrapAdmin.username" }}{{- end }}
{{- if not $ba.existingSecret }}{{ fail "controlPlane.apiserver.bootstrapAdmin.enabled=true requires controlPlane.apiserver.bootstrapAdmin.existingSecret (the password is never read from plaintext values)" }}{{- end }}
- name: KSQUAD_BOOTSTRAP_ADMIN_USERNAME
  value: {{ $ba.username | quote }}
- name: KSQUAD_BOOTSTRAP_ADMIN_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ $ba.existingSecret | quote }}
      key: {{ ($ba.passwordKey | default "password") | quote }}
{{- with $ba.teamId }}
- name: KSQUAD_BOOTSTRAP_ADMIN_TEAM_ID
  value: {{ . | quote }}
{{- end }}
{{- end -}}
{{- end -}}

{{/*
Build-browser reader-pod env (Story 8.7f / S4a, ISI-4005 / ISI-4073). DEGRADE-BY-DEFAULT:
emits KSQUAD_BUILD_READER_POD_ENABLED / KSQUAD_BUILD_READER_POD_IMAGE ONLY when
controlPlane.apiserver.buildReaderPod.enabled=true. When off, nothing is rendered and the
apiserver keeps config.go's BuildReaderPodEnabled=false default (snapshot-only, no pod launch).
The image defaults to the chart-versioned ghcr.io/k8squad/ksquad-buildreader:<tag> (same
registry/tag resolution as k8squad.image) unless an explicit .image override is set.
*/}}
{{- define "k8squad.buildReaderPodEnv" -}}
{{- $brp := .Values.controlPlane.apiserver.buildReaderPod | default dict -}}
{{- if $brp.enabled -}}
{{- $img := $brp.image | default (include "k8squad.image" (dict "root" . "component" "buildreader")) -}}
- name: KSQUAD_BUILD_READER_POD_ENABLED
  value: "true"
- name: KSQUAD_BUILD_READER_POD_IMAGE
  value: {{ $img | quote }}
{{- end -}}
{{- end -}}

{{/*
Session-cookie Secure attribute (ISI-3530). The apiserver defaults
SecureCookies=true; over a plain-HTTP gateway the browser drops the Secure
cookie and the Console middleware guard bounces every post-login navigation
back to /login. Resolve KSQUAD_SECURE_COOKIES from
controlPlane.apiserver.secureCookies:
  "true"/"false" → force that value explicitly.
  "" (auto)      → emit "false" ONLY when the gateway is enabled and TLS is NOT
                   terminated at it (http listener, https disabled); otherwise
                   emit nothing so the apiserver keeps its secure default.
*/}}
{{- define "k8squad.secureCookiesEnv" -}}
{{- $api := .Values.controlPlane.apiserver | default dict -}}
{{- $sc := $api.secureCookies | toString -}}
{{- if eq $sc "true" -}}
- name: KSQUAD_SECURE_COOKIES
  value: "true"
{{- else if eq $sc "false" -}}
- name: KSQUAD_SECURE_COOKIES
  value: "false"
{{- else -}}
{{- $gw := .Values.exposure.gateway | default dict -}}
{{- $https := false -}}
{{- if $gw.enabled -}}{{- with $gw.listeners -}}{{- with .https -}}{{- $https = .enabled -}}{{- end -}}{{- end -}}{{- end -}}
{{- if and $gw.enabled (not $https) }}
- name: KSQUAD_SECURE_COOKIES
  value: "false"
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Run-capability JWT signing-key env (ADR-0024a S3/D2, ISI-4922). The apiserver
MINTS short-lived run-capability tokens, the operator INJECTS them into
sandboxes, and the memory service VERIFIES them to gate the authoring lane — all
three consumers MUST resolve the SAME KSQUAD_JWT_SIGNING_KEY or the token path
stays inert (memory logs "run-capability-token auth off"). DEGRADE-BY-DEFAULT:
renders nothing unless controlPlane.auth.jwtSigningKey.existingSecret is set, so
token-auth is opt-in and every component keeps its auth-disabled in-code default
when unset. The Secret is created out-of-band (never inlined in values), e.g.:
  kubectl -n <ns> create secret generic ksquad-taskio-jwt \
    --from-literal=key='<random-signing-key>'
*/}}
{{- define "k8squad.jwtSigningEnv" -}}
{{- $j := (.Values.controlPlane.auth | default dict).jwtSigningKey | default dict -}}
{{- with $j.existingSecret }}
- name: KSQUAD_JWT_SIGNING_KEY
  valueFrom:
    secretKeyRef:
      name: {{ . | quote }}
      key: {{ ($j.key | default "key") | quote }}
{{- end }}
{{- end -}}
